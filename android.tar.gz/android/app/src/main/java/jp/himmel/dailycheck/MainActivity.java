package jp.himmel.dailycheck;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    static final String APP_URL = "https://iadocx-sudo.github.io/daily-check/";
    static final String ASSET_URL = "file:///android_asset/index.html";
    private static final int REQ_FILE = 42;
    private static final int REQ_VOICE = 43;

    private WebView wv;
    private ValueCallback<Uri[]> fileCb;
    private boolean usedFallback = false;
    private String pendingShare, pendingOpen;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#f3f4f1"));
        setContentView(wv);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        wv.addJavascriptInterface(new Bridge(), "DCNative");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String url = u.toString();
                if (url.startsWith(APP_URL) || url.startsWith("file:///android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame() && !usedFallback) {
                    usedFallback = true;
                    view.loadUrl(ASSET_URL);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) { deliver(); }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent it = new Intent(Intent.ACTION_GET_CONTENT);
                it.addCategory(Intent.CATEGORY_OPENABLE);
                it.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(it, "ファイルを選択"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
            }
        });

        handleIntent(getIntent());
        wv.loadUrl(APP_URL);
        Reminders.ensureChannel(this);
        Reminders.scheduleAll(this);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
        deliver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wv != null) wv.evaluateJavascript("document.dispatchEvent(new Event('visibilitychange'))", null);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            String t = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (t != null && !t.isEmpty()) pendingShare = t;
        }
        String open = intent.getStringExtra("openList");
        if (open != null) pendingOpen = open;
    }

    private void deliver() {
        if (wv == null) return;
        if (pendingOpen != null) {
            wv.evaluateJavascript("window.__dcOpen&&window.__dcOpen(" + JSONObject.quote(pendingOpen) + ")", null);
            pendingOpen = null;
        }
        if (pendingShare != null) {
            wv.evaluateJavascript("window.__dcShare&&window.__dcShare(" + JSONObject.quote(pendingShare) + ")", null);
            pendingShare = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VOICE) {
            if (res == RESULT_OK && data != null && wv != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty())
                    wv.evaluateJavascript("window.__dcVoice&&window.__dcVoice(" + JSONObject.quote(r.get(0)) + ")", null);
            }
            return;
        }
        if (req == REQ_FILE && fileCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (wv != null) { wv.destroy(); wv = null; }
        super.onDestroy();
    }

    /** Called from the page's JavaScript on a background thread. */
    private class Bridge {
        @JavascriptInterface public boolean isNative() { return true; }

        @JavascriptInterface public void setReminders(String json) {
            Reminders.save(MainActivity.this, json);
        }

        @JavascriptInterface public void setProgress(String json) {
            Reminders.saveProgress(MainActivity.this, json);
        }

        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                Intent it = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP");
                it.putExtra(RecognizerIntent.EXTRA_PROMPT, "TODOを話してください");
                try { startActivityForResult(it, REQ_VOICE); } catch (Exception e) {
                    if (wv != null) wv.evaluateJavascript("window.__dcToast&&window.__dcToast('音声入力を使えません')", null);
                }
            });
        }

        @JavascriptInterface public void testNotify() {
            Reminders.notify(MainActivity.this, "test", "毎日チェック", "通知のテストです");
        }

        @JavascriptInterface
        public boolean saveDownload(String name, String content) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                ContentResolver cr = getContentResolver();
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return false;
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) return false;
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                }
                return true;
            } catch (Exception ex) {
                return false;
            }
        }
    }
}
