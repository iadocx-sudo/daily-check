package jp.himmel.dailycheck;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String time = intent.getStringExtra("time");
        if (id == null) return;
        int[] p = Reminders.progress(c, id);
        boolean complete = p != null && p[1] > 0 && p[0] >= p[1];
        if (!complete) {
            String text = p == null ? "チェックの時間です" : ("いま " + p[0] + " / " + p[1] + "。1〜3分でチェック");
            Reminders.notify(c, id, title == null ? "毎日チェック" : title, text);
        }
        // schedule tomorrow
        if (time != null && !time.isEmpty()) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            try { Reminders.scheduleOne(c, am, id, title, time); } catch (Exception ignored) { }
        }
    }
}
