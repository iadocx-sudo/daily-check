package jp.himmel.dailycheck;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Daily reminder scheduling. Reminders come from the page as [{id,title,time:"HH:MM"}]. */
final class Reminders {
    static final String PREFS = "dc";
    static final String CH = "reminder";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void save(Context c, String json) {
        prefs(c).edit().putString("reminders", json).apply();
        scheduleAll(c);
    }

    static void saveProgress(Context c, String json) { prefs(c).edit().putString("progress", json).apply(); }

    static PendingIntent pi(Context c, String id, String title, String time, int flags) {
        Intent it = new Intent(c, AlarmReceiver.class);
        it.setAction("jp.himmel.dailycheck.REMIND." + id);
        it.putExtra("id", id);
        it.putExtra("title", title);
        it.putExtra("time", time);
        return PendingIntent.getBroadcast(c, id.hashCode(), it, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    static void scheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences p = prefs(c);
        // cancel previously scheduled
        try {
            JSONArray old = new JSONArray(p.getString("scheduled", "[]"));
            for (int i = 0; i < old.length(); i++) {
                PendingIntent x = pi(c, old.getString(i), "", "", PendingIntent.FLAG_NO_CREATE);
                if (x != null) { am.cancel(x); x.cancel(); }
            }
        } catch (Exception ignored) { }
        JSONArray done = new JSONArray();
        try {
            JSONArray arr = new JSONArray(p.getString("reminders", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String id = o.getString("id"), title = o.optString("title", "毎日チェック"), time = o.getString("time");
                scheduleOne(c, am, id, title, time);
                done.put(id);
            }
        } catch (Exception ignored) { }
        p.edit().putString("scheduled", done.toString()).apply();
    }

    static void scheduleOne(Context c, AlarmManager am, String id, String title, String time) {
        String[] hm = time.split(":");
        int h = Integer.parseInt(hm[0]), m = Integer.parseInt(hm[1]);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, h);
        cal.set(Calendar.MINUTE, m);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1);
        PendingIntent x = pi(c, id, title, time, PendingIntent.FLAG_UPDATE_CURRENT);
        long at = cal.getTimeInMillis();
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, x);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, x);
    }

    static void ensureChannel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "チェックの時間", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("毎日のチェックリストの時刻にお知らせします");
            nm.createNotificationChannel(ch);
        }
    }

    /** Returns int[]{done,total} for today's progress of the list, or null if unknown. */
    static int[] progress(Context c, String id) {
        try {
            Calendar now = Calendar.getInstance();
            String today = String.format("%04d-%02d-%02d", now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH));
            JSONArray arr = new JSONArray(prefs(c).getString("progress", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (id.equals(o.optString("id"))) {
                    int total = o.optInt("total", 0);
                    int done = today.equals(o.optString("date")) ? o.optInt("done", 0) : 0;
                    return new int[]{done, total};
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    static void notify(Context c, String id, String title, String text) {
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("openList", id);
        PendingIntent tap = PendingIntent.getActivity(c, ("open" + id).hashCode(), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        try { nm.notify(id.hashCode(), n); } catch (SecurityException ignored) { }
    }
}
